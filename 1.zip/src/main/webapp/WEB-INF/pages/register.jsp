<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="false" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>注册 - 图书管理系统</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <script type="text/javascript" src="${pageContext.request.contextPath}/lib/jquery-3.4.1/jquery-3.4.1.min.js"></script>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/lib/layui-v2.5.5/css/layui.css" media="all">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/public.css" media="all">

    <style>
        html, body {width: 100%;height: 100%;overflow: auto}
        body {background: url("${pageContext.request.contextPath}/images/loginbg.png") no-repeat center;}
        body:after {content:'';background-repeat:no-repeat;background-size:cover;-webkit-filter:blur(3px);-moz-filter:blur(3px);-o-filter:blur(3px);-ms-filter:blur(3px);filter:blur(3px);position:absolute;top:0;left:0;right:0;bottom:0;z-index:-1;}
        .layui-container {width: 100%;min-height: 100%;}
        .admin-login-background {width:450px;margin: 50px auto;opacity:0.9;}
        .logo-title {text-align:center;letter-spacing:2px;padding:14px 0;}
        .logo-title h1 {color:#1E9FFF;font-size:25px;font-weight:bold;}
        .login-form {background-color:#fff;border:1px solid #fff;border-radius:3px;padding:14px 20px;box-shadow:0 0 8px #eeeeee;}
        .login-form .layui-form-item {position:relative;}
        .login-form .layui-form-item label {position:absolute;left:1px;top:1px;width:38px;line-height:36px;text-align:center;color:#d2d2d2;}
        .login-form .layui-form-item input {padding-left:36px;}
        .register-link {text-align:center;margin-top:10px;}
    </style>
</head>
<body>

<div class="layui-container">
    <div class="admin-login-background">
        <div class="layui-form login-form">
            <form class="layui-form" action="${pageContext.request.contextPath}/register" method="post">
                <div class="layui-form-item logo-title">
                    <h1>图书管理系统 - 注册</h1>
                    <div style="color: red;text-align: center;">${msg}</div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-username"></label>
                    <input type="text" name="username" lay-verify="required" placeholder="用户名" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-password"></label>
                    <input type="password" name="password" lay-verify="required" placeholder="密码" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-password"></label>
                    <input type="password" name="confirmPassword" lay-verify="required" placeholder="确认密码" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-username"></label>
                    <input type="text" name="realName" lay-verify="required" placeholder="真实姓名" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-username"></label>
                    <select name="sex" lay-verify="required">
                        <option value="">请选择性别</option>
                        <option value="男">男</option>
                        <option value="女">女</option>
                    </select>
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-date"></label>
                    <input type="date" name="birthday" lay-verify="required" placeholder="出生日期" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-home"></label>
                    <input type="text" name="address" lay-verify="required" placeholder="地址" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-phone"></label>
                    <input type="text" name="tel" lay-verify="required" placeholder="电话" autocomplete="off" class="layui-input" >
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-username"></label>
                    <input type="text" name="id_card" lay-verify="required" placeholder="身份证号码" autocomplete="off" class="layui-input" maxlength="20">
                </div>
                <div class="layui-form-item">
                    <label class="layui-icon layui-icon-email"></label>
                    <input type="email" name="email" lay-verify="required" placeholder="邮箱" autocomplete="off" class="layui-input" maxlength="30">
                </div>
                <!-- 隐藏字段，默认用户类型为读者 -->
                <input type="hidden" name="type" value="2">

                <div class="layui-form-item">
                    <button class="layui-btn layui-btn-normal layui-btn-fluid" lay-submit="" lay-filter="register">注册</button>
                </div>
                <div class="register-link">
                    <a href="${pageContext.request.contextPath}/login">已有账号？点击登录</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/lib/layui-v2.5.5/layui.js" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form'], function () {
        var form = layui.form,
            layer = layui.layer;
        form.on('submit(register)', function (data) {
            data = data.field;
            if (data.username == '') {
                layer.msg('用户名不能为空');
                return false;
            }
            if (data.password == '') {
                layer.msg('密码不能为空');
                return false;
            }
            if (data.confirmPassword == '') {
                layer.msg('确认密码不能为空');
                return false;
            }
            if (data.password != data.confirmPassword) {
                layer.msg('两次输入的密码不一致');
                return false;
            }

        });
    });
</script>
</body>
</html>