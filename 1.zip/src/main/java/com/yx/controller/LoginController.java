package com.yx.controller;


import com.yx.po.Admin;
import com.yx.po.ReaderInfo;
import com.yx.service.AdminService;
import com.yx.service.ReaderInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Date;

@Controller
public class LoginController {

    @Autowired
    private AdminService adminService;
    @Autowired
    private ReaderInfoService readerService;

    /**
     * 登录页面的转发
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }


    /**
     * 登录验证
     */
    @RequestMapping("/loginIn")
    public String loginIn(HttpServletRequest request, Model model) {
        //获取用户名与密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String type = request.getParameter("type");

        HttpSession session = request.getSession();
        //判断用户名和密码
        if (type.equals("1")) {//管理员信息
            //用户名和密码是否正确
            Admin admin = adminService.queryUserByNameAndPassword(username, password);
            if (admin == null) {//该用户不存在
                model.addAttribute("msg", "用户名或密码错误");
                return "login";
            }
            session.setAttribute("user", admin);
            session.setAttribute("type", "admin");
        } else {//来自读者信息表
            ReaderInfo readerInfo = readerService.queryUserInfoByNameAndPassword(username, password);
            if (readerInfo == null) {
                model.addAttribute("msg", "用户名或密码错误");
                return "login";
            }
            session.setAttribute("user", readerInfo);
            session.setAttribute("type", "reader");
        }

        return "index";
    }

    /**
     * 退出功能
     */

    @GetMapping("loginOut")

    public String loginOut(HttpServletRequest request) {

        HttpSession session = request.getSession();

        session.invalidate();//注销

        return "/login";
    }

    /**
     * 注册页面
     */
    @GetMapping("registerPage")
    public String registerPage() {
        return "register";
    }

    /**
     * 注册功能 - 仅支持读者注册
     */
    @RequestMapping("register")
    public String register(HttpServletRequest request, Model model) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String realName = request.getParameter("realName");
        String sex = request.getParameter("sex");
        String birthdayStr = request.getParameter("birthday");
        String address = request.getParameter("address");
        String tel = request.getParameter("tel");
        String email = request.getParameter("email");
        String id_card = request.getParameter("id_card");

        // 验证密码是否一致
        if (!password.equals(confirmPassword)) {
            model.addAttribute("msg", "两次输入的密码不一致");
            return "register";
        }

        // 服务器端字段长度验证和截断
        if (username != null) {
            if (username.length() > 20) {
                model.addAttribute("msg", "用户名长度不能超过20个字符");
                return "register";
            }
        }
        if (password != null) {
            if (password.length() > 20) {
                model.addAttribute("msg", "密码长度不能超过20个字符");
                return "register";
            }
        }
        if (realName != null) {
            if (realName.length() > 20) {
                model.addAttribute("msg", "真实姓名长度不能超过20个字符");
                return "register";
            }
        }
        if (address != null) {
            if (address.length() > 100) {
                model.addAttribute("msg", "地址长度不能超过100个字符");
                return "register";
            }
        }
        if (tel != null) {
            if (tel.length() > 20) {
                model.addAttribute("msg", "电话号码长度不能超过20个字符");
                return "register";
            }
        }
        if (id_card != null) {
            if (id_card.length() > 20) {
                model.addAttribute("msg", "身份证号码长度不能超过20个字符");
                return "register";
            }
        }
        if (email != null) {
            if (email.length() > 30) {
                // 截断到30个字符以适应数据库字段
                email = email.substring(0, 30);
            }
        }

        // 检查用户名是否已存在
        ReaderInfo readerInfo = readerService.queryReaderByName(username);
        if (readerInfo != null) {
            model.addAttribute("msg", "该用户名已存在");
            return "register";
        } else {
            // 创建新读者
            ReaderInfo newReader = new ReaderInfo();
            newReader.setUsername(username);
            newReader.setPassword(password);
            newReader.setRealName(realName);
            newReader.setSex(sex);

            // 处理生日日期
            try {
                if (birthdayStr != null && !birthdayStr.isEmpty()) {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                    java.util.Date birthday = sdf.parse(birthdayStr);
                    newReader.setBirthday(new java.sql.Date(birthday.getTime()));
                }
            } catch (Exception e) {
                model.addAttribute("msg", "日期格式不正确");
                return "register";
            }

            newReader.setAddress(address);
            newReader.setTel(tel);
            newReader.setEmail(email);
            newReader.setId_card(id_card);
            newReader.setRegisterDate(new Date());
            // 生成随机读者卡号
            String readerNumber = "RD" + System.currentTimeMillis();
            newReader.setReaderNumber(readerNumber);

            readerService.addReaderInfoSubmit(newReader);

            model.addAttribute("msg", "注册成功，请登录");
            return "login";
        }
    }
}
